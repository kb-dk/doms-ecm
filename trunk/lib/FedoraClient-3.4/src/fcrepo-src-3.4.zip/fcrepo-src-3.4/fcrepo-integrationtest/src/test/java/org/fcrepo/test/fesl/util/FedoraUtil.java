package org.fcrepo.test.fesl.util;

import org.fcrepo.test.FedoraTestCase;


public class FedoraUtil
        extends FedoraTestCase {

}
